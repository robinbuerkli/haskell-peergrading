module MainUtil where
import System.Directory ( createDirectoryIfMissing, listDirectory )
import Data.List

-- | all criterials for grading
criterias :: [String]
criterias = ["N1", "N2", "F1" , "F2", "F3"]

data Grader = MkGrader (String, [Int])

-- | gets all author names from the data directory
getAuthors :: IO [String]
getAuthors = listDirectory "data"

-- | gets all graders from the directory of one author (given as parameter)
getGraders :: String -> IO [Grader]
getGraders author = do
    graderNames <- listDirectory ("data/" ++ author)
    grades <- mapM (getGrades author) graderNames
    return (map createGrader (zip graderNames grades))

-- | gets all grades from a file (filepath created with author name and grader name (1. and 2. Parameter respectively))
getGrades :: String -> String -> IO [Int]
getGrades author filename = do
        let name = reverse (drop 4 (reverse filename))
        content <- readFile ("data/" ++ author ++ "/" ++ name ++ ".txt")
        let grades = read content :: [Int]
        
        return grades


-- | Creates a Grader type given the name of the Grader and his grades as a Touple (given as parameter)
createGrader :: (String, [Int]) -> Grader
createGrader (name, grades) = (MkGrader (reverse (drop 4 (reverse name)), grades))

-- | Writes given grades into file. 1. Parameter : Author name, 2. Parameter: Grader name, 3. Parameter: grades
writeGradeOnFile :: String -> String -> [Int] -> IO ()
writeGradeOnFile author grader content = do
    createDirectoryIfMissing True ("data/" ++ author)
    writeFile ("data/" ++ author ++ "/" ++ grader ++ ".txt") (show content)
    return ()


-- | gets the median of a given Double list
getMedian :: [Double] -> Double
getMedian list | odd listLenght = (sort list) !! middle
               | even listLenght = medianEven
                     where listLenght = length list
                           middle = div listLenght 2
                           medianEven = ((sort list) !! middle + (sort list) !! (middle+1)) / 2


-- | gets a column from a List of Graders with the given index (Graders have a list of grades. These grades )
getColumn :: [Grader] -> Int -> [Int]
getColumn graders n = map (getGrade n) graders

-- | gets a grade from a given Grader and the index of the grade
getGrade :: Int -> Grader -> Int
getGrade index (MkGrader (_ , grades)) = (!! index) grades;

