{-# LANGUAGE OverloadedStrings #-}
-- | All web services are processed in this module
module Hgrade where

import           Web.Scotty
import           Control.Monad.IO.Class (liftIO)
import           Network.Wai.Middleware.RequestLogger ( logStdoutDev )
import           Html
import qualified Data.Text.Lazy as T
import MainUtil

-- | main function. Run during start of application
main :: IO ()
main = do
  putStrLn "Good Luck!"
  scotty 4000 $ do
    middleware logStdoutDev
    
    get "/" indexHtml

    get "/static/styles.css" $ file "static/styles.css"

    get "/authors" $ do
      authors <- liftIO getAuthors
      authorsPage authors

    get "/authors/:name" $ do
      author <- param "name"
      graders <- liftIO (getGraders author)
      html (T.pack (createHtml ([h1 author] ++ [createGraderTable graders])))

    get "/grade" $ do
      gradingPage  
    
    post "/grade" $ do
      parameters <- params
      liftIO ( print  (show parameters) )
      author <- param "author"
      grader <- param "grader"
      criteriaRatings <-  mapM getCriteriaParam criterias
      liftIO(writeGradeOnFile author grader criteriaRatings)
      indexHtml


-- | gets all criteria param from post request
getCriteriaParam :: String -> ActionM (Int)
getCriteriaParam identifier = do
   criteria <- param (T.pack (identifier))
   return (read criteria)



-- | creates the index page
indexHtml :: ActionM () 
indexHtml = html (T.pack (createHtml [h1 "Hgrade - Peergrading in Haskell", ul [li [a "/authors" "Grading overview"], li [a "/grade" "Submit Grading"]]]))

-- | creates the grading page
gradingPage :: ActionM ()
gradingPage = html (T.pack (createHtml [form "/grade" "POST" ([p "Author:", inputTag "author" "text", p "Grader:", inputTag "grader" "text"] ++ createCriteriaInputs ++ [submitButton "Submit"])]))

-- | creates the authors page
authorsPage :: [String] -> ActionM ()
authorsPage authors = html (T.pack (createHtml (createAuthorLinks authors)))