{-# LANGUAGE OverloadedStrings #-}
-- | Module for creation of Html.
module Html where
import Data.List ( intercalate ) 
import MainUtil ( Grader(..), criterias )

-- | Datatype for representing a Html Tag
data HtmlTag = LastTag String [String] String | Tag String [String] [HtmlTag] | VoidTag String [String]

-- | Method to convert HtmlTag into a String
toString :: HtmlTag -> String
toString (Tag name attributes ts) = startTag name attributes ++ "\n" ++ concat (map toString ts) ++ endTag (name) ++ "\n"
toString (LastTag name attributes content) = startTag name attributes ++ content ++ endTag name ++ "\n"
toString (VoidTag name attributes) = voidTag name attributes ++ "\n"

-- | represents a beginning tag. ex. : <h1>. Content is first parameter, List of Attributes second
startTag :: String -> [String] -> String
startTag name attributes = "<" ++ name ++ " " ++ (intercalate " " attributes) ++ ">"

-- | represents a ending tag. ex. : </h1>. Content is first parameter
endTag :: String -> String
endTag name = "</" ++ name ++ ">"

-- | represents a self closing tag (void tag). ex. : <br/>. Content is first parameter, List of Attributes second
voidTag :: String -> [String] -> String
voidTag name attributes = "<" ++ name ++ " " ++ (intercalate " " attributes) ++ " />"

-- | represents a Html h1 tag. Content of tag is the parameter
h1 :: String -> HtmlTag
h1 content = LastTag "h1" [] content

-- | represents a Html h2 tag. Content of tag is the parameter
h2 :: String -> HtmlTag
h2 content = LastTag "h2" [] content

-- | represents a basic html tag 
htmlTag :: [HtmlTag] -> String
htmlTag [] = toString (LastTag "html" [] "")
htmlTag ts = toString (Tag "html" [] ts)

-- | represents a Html body tag
body :: [HtmlTag] -> HtmlTag
body [] = (LastTag "body" [] "")
body ts = (Tag "body" [] ts)

-- | represents a Html body tag converted to a String
bodyString :: [HtmlTag] -> String
bodyString [] = toString (LastTag "body" [] "")
bodyString ts = toString (Tag "body" [] ts)

-- | represents a Html div tag
div :: [HtmlTag] -> HtmlTag
div [] = (LastTag "div" [] "")
div ts = (Tag "div" [] ts)

-- | represents a Html head tag
htmlHead :: [HtmlTag] -> HtmlTag
htmlHead [] = (LastTag "head" [] "")
htmlHead ts = (Tag "head" [] ts)

-- | represents a Html link tag.  Attribute rel is first parameter, attribute href is second paramenter
link :: String -> String -> HtmlTag
link rel href = (VoidTag "link" ["rel=\"" ++ rel ++ "\"", "href=\"" ++ href ++ "\""])

-- | represents a Html ul tag. Has as parameter a list of other HtmlTags
ul :: [HtmlTag] -> HtmlTag
ul [] = (LastTag "ul" [] "")
ul ts = (Tag "ul" [] ts)

-- | represents a Html li tag. Has as parameter a list of other HtmlTags
li :: [HtmlTag] -> HtmlTag
li [] = (LastTag "li" [] "")
li ts = (Tag "li" [] ts)

-- | represents a Html a tag. Attribute href is first parameter, second parameter is the text of the tag.
a :: String -> String -> HtmlTag
a href content = LastTag "a" ["href=\"" ++ href ++ "\""] content

-- | represents a Html p tag. Parameter is the text of the tag.
p :: String -> HtmlTag
p content = LastTag "p" [] content

-- | represents a Html form tag. First parameter is the action attribute, second is the method.
form :: String -> String -> [HtmlTag] -> HtmlTag
form action method [] = (LastTag "form" ["action=\"" ++ action ++ "\"", "method=\"" ++ method ++ "\"" ] "")
form action method ts = (Tag "form" ["action=\"" ++ action ++ "\"", "method=\"" ++ method ++ "\"" ] ts)

-- | represents a Html input tag. First parameter is the name attribute, second is the type attribute
inputTag :: String -> String -> HtmlTag
inputTag identifier inputType = LastTag "input" ["name=\"" ++ identifier ++ "\"", "type=\"" ++ inputType ++"\"" ] ""

-- | represents a submit Button (input Tag with type submit). Text of Button is the parameter
submitButton :: String -> HtmlTag
submitButton value = LastTag "input" ["value=\"" ++ value ++ "\"", "type=\"submit\"" ] ""

-- | represents a Html table tag. Has as parameter a list of other HtmlTags
table :: [HtmlTag] -> HtmlTag
table [] = (LastTag "table" [] "")
table ts = (Tag "table" [] ts)

-- | represents a Html tr tag. Has as parameter a list of other HtmlTags
tr :: [HtmlTag] -> HtmlTag
tr [] = (LastTag "tr" [] "")
tr ts = (Tag "tr" [] ts)

-- | represents a Html th tag. Has as parameter the text of the tag
th :: String -> HtmlTag
th content = LastTag "th" [] content

-- | represents a Html td tag. Has as parameter the text of the tag
td :: String -> HtmlTag
td content = LastTag "td" [] content

-- | represents a Html div tag. Has as parameter a list of other HtmlTags
divTag :: [HtmlTag] -> HtmlTag
divTag [] = (LastTag "div" [] "")
divTag ts = (Tag "div" [] ts)

-- | creates a whole html page. Has as parameter a list of other HtmlTags, that will be added into the body of the Html
createHtml :: [HtmlTag] -> String
createHtml content = "<!doctype html>" ++ "\n" ++ htmlTag [htmlHead [link "stylesheet" "/static/styles.css"], body content]

-- | creates a list of HtmlTags that presents all given names in a list as html (String list of authors is given as first parameter)
createAuthorLinks :: [String] -> [HtmlTag]
createAuthorLinks names = map createAuthorLink names

-- | mapping method used for method createAuthorLinks
createAuthorLink :: String -> HtmlTag
createAuthorLink name = li [a ("/authors/" ++ name) name]

-- | creates a html table that has all ratings of the given graders
createGraderTable :: [Grader] -> HtmlTag
createGraderTable [] = table[tr (th "" : map th criterias)]
createGraderTable graders = table ((tr (th "" : map th criterias)) : (map createGraderRow graders))

-- | mapping method used for method createGraderTable. creates one row of the grader table
createGraderRow :: Grader -> HtmlTag
createGraderRow (MkGrader (name, grades)) = tr (td name : map td (map show grades))

-- | creates html inputs + labels (p tag) for all defined criterias in const criterias
createCriteriaInputs :: [HtmlTag]
createCriteriaInputs = map createCriteriaInput criterias

-- | creates one row of the list of components from createCriteriaInputs
createCriteriaInput :: String -> HtmlTag
createCriteriaInput identifier = divTag [p (identifier ++ ":"), inputTag identifier "text"]