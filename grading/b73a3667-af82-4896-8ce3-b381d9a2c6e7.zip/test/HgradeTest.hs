module Main (main) where

import Hgrade.Math (colsToRows,median,histogram)
import Test.Tasty
import Test.Tasty.HUnit



main :: IO ()
main = defaultMain tests

tests :: TestTree
tests = testGroup "Tests" [unitTests]

unitTests :: TestTree
unitTests = testGroup "Unit tests"
  [ testCase "colsToRows two lists 3 elems" $
      colsToRows [[1,1,1],[2,2,2]] @?= [[1,2],[1,2],[1,2]],

    testCase "colsToRows three lists 3 elems" $
      colsToRows [[1,1,1],[2,2,2],[3,3,3]] @?= [[1,2,3],[1,2,3],[1,2,3]],

    testCase "colsToRows four lists 3 elems" $
      colsToRows [[1,1,1],[2,2,2],[3,3,3],[4,4,4]] @?= [[1,2,3,4],[1,2,3,4],[1,2,3,4]],

    testCase "colsToRows two lists 4 elems" $
      colsToRows [[1,1,1,1],[2,2,2,2]] @?= [[1,2],[1,2],[1,2],[1,2]],

    testCase "median odd unsorted" $
      median [1,0,1] @?= 1,

    testCase "median odd sorted" $
      median [0,1,1] @?= 1,

    testCase "median odd sorted 5 elems" $
      median [0,1,1,2,2] @?= 1,

    testCase "median even 2 elem" $
      median [1,0] @?= 0.5,

    testCase "median even 4 elem" $
      median [0,0,2,2] @?= 1,

    testCase "median even 4 elem fractional" $
      median [0,1,2,2] @?= 1.5, 
    
    testCase "histogram counts 3 elem" $
      histogram [0,1,2] @?= (1,1,1),

    testCase "histogram counts 4 elem" $
      histogram [0,1,2,0] @?= (2,1,1),

    testCase "histogram counts 5 elem" $
      histogram [0,1,1,2,2] @?= (1,2,2)
  ]

