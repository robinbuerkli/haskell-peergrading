{-# LANGUAGE OverloadedStrings #-}

module Hgrade where

import qualified Hgrade.Html
import qualified Hgrade.FileHandling
import qualified Hgrade.Util
import           Web.Scotty
import           Control.Monad (mapM)
import           Control.Monad.IO.Class (liftIO)
import           Network.Wai.Middleware.RequestLogger ( logStdoutDev )
import           System.Directory (listDirectory,createDirectoryIfMissing)
import qualified Data.Text.Lazy as T

main :: IO ()
main = do
  putStrLn "Good Luck!"
  scotty 4000 $ do
    middleware logStdoutDev
    
    get "/" $ file "static/index.html"

    get "/favicon.ico" $ file "static/favicon.ico"

    get "/static/styles.css" $ file "static/styles.css"

    get "/authors" $ do
      _ <- liftIO (createDirectoryIfMissing False ("data"))
      fileList <- liftIO (listDirectory "data")
      html (T.pack (Hgrade.Html.createOverviewPage(fileList)))

    get "/authors/:author_name" $ do
      authorName <- param "author_name"
      let path = "data/" ++ authorName
      fileList <- liftIO (listDirectory path)
      let filePaths = map ((path ++ "/") ++) fileList
      content <- liftIO (mapM Hgrade.FileHandling.loadTxtFile filePaths)
      html (T.pack (Hgrade.Html.createEvaluationPage((authorName,fileList,content))))

    get "/grade" $ do
      html (T.pack(Hgrade.Html.createGradingPage))
    
    post "/grade" $ do
      author <- param "Author"
      grader <- param "Grader"
      _ <- liftIO (createDirectoryIfMissing False ("data/"++author))
      val <- mapM param (map T.pack Hgrade.Util.category)
      liftIO(writeFile ("data/"++author++"/"++grader++".txt") ((T.unpack((T.cons '[' (T.append (T.intersperse ',' (T.pack val)) "]"))))))
      redirect "/authors"