{-|
Dieses Modul enthält Funktionen für das File Handling.
-}

module Hgrade.FileHandling where

import           System.Directory

-- |Lädt Text File
loadTxtFile :: String -> IO String
loadTxtFile file = do
    exists <- doesFileExist file
    if not exists then return []
    else do
        content <- readFile file
        let score = if null content then [] else (content)
        return $! score