{-|
Dieses Modul enthält Funktionen um die HTML Seiten zu generieren.
-}

module Hgrade.Html where

import qualified Hgrade.Util
import qualified Hgrade.Math

-- |Erzeugt Autoren Seite. Nimmt Liste von Links entgegen
createOverviewPage :: [String] -> String
createOverviewPage authors = unlines [
  Hgrade.Util.htmlHead,
  "  <body>",
  "    <h1>Authors</h1>",
  "    <ul> " ++ (Hgrade.Util.createAuthorLinks authors) ++ "</ul>",
  "  </body>",
  "</html>"]

-- |Erzeugt Auswertungsseite mit Autorenname, Gradernamen und den Gradings
createEvaluationPage :: (String,[String], [String]) -> String
createEvaluationPage (author,names,content) = unlines [
  Hgrade.Util.htmlHead,
  "  <body>",
  "    <h1> Author: " ++ author ++ "</h1>",
  "     <table>" ++ Hgrade.Util.tableStyle ++ "<tr><th></th>" ++ (Hgrade.Util.createTableHeader Hgrade.Util.category) ++ "</tr>",
          unlines(map Hgrade.Util.makeContentRow(zip (map Hgrade.Util.createName (map Hgrade.Util.removeTxtEnding names)) (map Hgrade.Util.createContent (map(read :: String -> [Int]) content)))),
          (Hgrade.Util.makeMedianRow (Hgrade.Util.createContentFloat(map Hgrade.Math.median (Hgrade.Math.colsToRows(map(read :: String -> [Int]) content ))))),
          (Hgrade.Util.makeHistoRow (Hgrade.Util.createHistoTable ((length names),(map Hgrade.Math.histogram (Hgrade.Math.colsToRows(map(read :: String -> [Int]) content )))))),
  "     </table>",
  "  </body>",
  "</html>"]

-- |Erzeugt Bewertungsseite anhand der Kategorien
createGradingPage :: String
createGradingPage = unlines [
  Hgrade.Util.htmlHead,
  "  <body>",
  "    <h1>Grade</h1>",
  "    <form action='/grade' method='post'>",
        (Hgrade.Util.createInputField "Author"),
        (Hgrade.Util.createInputField "Grader"),
        (Hgrade.Util.createGradeForm Hgrade.Util.category),
  "     <input type='submit' value='Send'></input>",
  "    </form>",
  "  </body>",
  "</html>"]