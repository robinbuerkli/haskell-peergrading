{-|
Dieses Modul enthält Utility Funktionen für die Erstellung der HTML Seiten, HTML Elementen. Zusätzlich ist die Katergorien Liste hier zu finden und das Entfernen der .txt Endung
-}

module Hgrade.Util where

-- |String für die Kategorien
category :: [String]
category = ["N1","N2","F1","F2","F3"]

-- |Erzeugt List von Links aus der Liste der Autorennamen
createAuthorLinks :: [String] -> String
createAuthorLinks []     = ""
createAuthorLinks [s]    = "<li><a href=/authors/" ++ s ++ ">" ++ s ++ "</a></li>" 
createAuthorLinks (s:ss) = "<li><a href=/authors/" ++ s ++ ">" ++ s ++ "</a></li>" ++ createAuthorLinks ss

-- |Erzeugt den Header der Tabelle anhand der Kategorien
createTableHeader :: [String] -> String
createTableHeader [] = ""
createTableHeader [s] = "<th>" ++ s ++ "</th>"
createTableHeader (s:ss) = "<th>" ++ s ++ "</th>" ++ createTableHeader ss

-- |Wrappt Namen in <td> Tags
createName :: String -> String
createName s = "<td>" ++ s  ++ "</td>"

-- |Wrappt Ergbenisse in <td> Tags
createContent :: [Int] -> String
createContent [] = ""
createContent [i] = "<td>" ++ show i ++ "</td>"
createContent (i:is) = "<td>" ++ show i ++ "</td>" ++ createContent is 

-- |Wrappt Ergbenisse in <td> Tags
createContentFloat :: [Float] -> String
createContentFloat [] = ""
createContentFloat [i] = "<td>" ++ show i ++ "</td>"
createContentFloat (i:is) = "<td>" ++ show i ++ "</td>" ++ createContentFloat is 

-- |Wrappt String in <tr> Tags
makeRow :: String -> String
makeRow s = "<tr>" ++ s ++ "</tr>"

-- |Wrappt String in <tr> Tags
makeMedianRow :: String -> String
makeMedianRow s = "<tr><td>Median</td>" ++ s ++ "</tr>"

-- |Wrappt Gradernamen und Gradings in <tr> Tags
makeContentRow :: (String,String) -> String
makeContentRow (s,i) = "<tr>" ++ s ++ i ++ "</tr>"

-- |Erzeugt Histogramm Row
makeHistoRow :: String -> String
makeHistoRow s = "<tr><td>Histograms</td>" ++ s ++ "</tr>"

-- |Wrappt die Histogram Zeilen in eine Tabelle
createHistoTable :: (Int,[(Int,Int,Int)]) -> String
createHistoTable (_,[]) = ""
createHistoTable (h,[(a,b,c)]) = "<td>" ++ tableStyle ++ "<table>" ++ createHistoRow (h,a,b,c) ++ "</table></td>"
createHistoTable (h,((a,b,c):d)) = "<td>" ++ tableStyle ++ "<table>" ++ createHistoRow (h,a,b,c) ++ "</table></td>" ++ createHistoTable (h,d)

-- |Zeichnet die Histogram Zeilen
createHistoRow :: (Int,Int,Int,Int) -> String
createHistoRow (0,_,_,_) = ""
createHistoRow (h,0,0,0) = "<tr>" ++ createHistoRow (h - 1, 0, 0 ,0)            ++ createWhiteField ++ createWhiteField ++ createWhiteField ++ "</tr>"
createHistoRow (h,a,0,0) = "<tr>" ++ createHistoRow (h - 1,a - 1, 0 ,0)         ++ createBlackField ++ createWhiteField ++ createWhiteField ++ "</tr>"
createHistoRow (h,0,b,0) = "<tr>" ++ createHistoRow (h - 1,0, b - 1 ,0)         ++ createWhiteField ++ createBlackField ++ createWhiteField ++ "</tr>"
createHistoRow (h,a,b,0) = "<tr>" ++ createHistoRow (h - 1,a - 1, b - 1 ,0)     ++ createBlackField ++ createBlackField ++ createWhiteField ++ "</tr>"
createHistoRow (h,0,0,c) = "<tr>" ++ createHistoRow (h - 1,0, 0 ,c - 1)         ++ createWhiteField ++ createWhiteField ++ createBlackField ++ "</tr>"
createHistoRow (h,0,b,c) = "<tr>" ++ createHistoRow (h - 1,0, b - 1 ,c - 1)     ++ createWhiteField ++ createBlackField ++ createBlackField ++ "</tr>"
createHistoRow (h,a,0,c) = "<tr>" ++ createHistoRow (h - 1,a - 1, 0 ,c - 1)     ++ createBlackField ++ createWhiteField ++ createBlackField ++ "</tr>"
createHistoRow (h,a,b,c) = "<tr>" ++ createHistoRow (h - 1,a - 1, b - 1 ,c - 1) ++ createBlackField ++ createBlackField ++ createBlackField ++ "</tr>"

-- |Zeichnet ein weisses Feld
createWhiteField :: String
createWhiteField = "<td bgcolor=\"white\" style=\"height:20px;width:20px\"></td>"

-- |Zeichnet ein schwarzes Feld
createBlackField :: String
createBlackField = "<td bgcolor=\"black\" style=\"height:20px;width:20px\"></td>"

-- |Erzeugt Formular für das Grading zusammen Anhand der Kategorien
createGradeForm :: [String] -> String
createGradeForm [] = ""
createGradeForm [s] = "<label for='" ++ s ++ "'>" ++ s ++ ":</label> <input type='text' id='" ++ s ++ "' name='" ++ s ++ "'></input><br>"
createGradeForm (s:ss) = "<label for='" ++ s ++ "'>" ++ s ++ ":</label> <input type='text' id='" ++ s ++ "' name='" ++ s ++ "'></input><br>" ++ createGradeForm ss

-- |Erzeugt ein Input Feld mit Label
createInputField :: String -> String
createInputField s =   "<label for='" ++ s ++ "'>" ++ s ++ ":</label><input type='text' id='" ++ s ++ "' name='" ++ s ++ "'></input><br>"

-- |Txt Endung von Filenamen entfernen
removeTxtEnding :: String -> String
removeTxtEnding s = reverse(drop 4 (reverse s)) 

-- |Styling der Tables
tableStyle :: String
tableStyle = "<style>table, th, td {border: 1px solid black;border-collapse: collapse;}</style>"

-- |Enthält die Head Infos für HTML Seiten
htmlHead :: String
htmlHead =  "<!doctype html><html lang='en'><head></head>"