{-|
Dieses Modul enthält Mathematik Funktionen für die Median Berechnung und das Histogram.
-}

module Hgrade.Math where

import Data.List (sort)

-- |Berechnung des Medians
median :: [Int] -> Float
median [] = 0
median i = middle(sort i)

-- |Hilfsfunktion für die Berechnung des Medians
middle :: [Int] -> Float
middle [] = 0
middle [i] = fromIntegral i
middle is = if odd l
            then fromIntegral(head(drop (half) (take (half+1) is)))
            else mean(drop (half-1) (take (half+1) is))
            where l = length is
                  half = div l 2
                  mean [] = 0
                  mean [_] = 0
                  mean [a,b] = (fromIntegral (a + b)) / 2.0
                  mean (_:_:_:_) = 0

-- |Zählt Anzahl der Einträge in Int Liste für das Zeichnen des Histograms
histogram :: [Int] -> (Int, Int, Int)
histogram = foldl incrementer (0,0,0)
            where incrementer (zero, one, two) h | h == 0 = (zero + 1, one, two)
                  incrementer (zero, one, two) h | h == 1 = (zero, one + 1, two)
                  incrementer (zero, one, two) _ | otherwise = (zero, one, two + 1)

-- |Transponiert die Eingabewerte, Vorbereitungsschritt für Median und Histogram
colsToRows :: [[a]] -> [[a]]
colsToRows [[]]    = []
colsToRows ([]:cols)  = colsToRows cols
colsToRows cols    = (map head cols) : colsToRows (map tail cols)