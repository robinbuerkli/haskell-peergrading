--Modul für AnalysePage
module Analyse where

    --jedes grader textfile aus authors auslesen und in tabelle ausgeben
    --grader als liste mit den parametern n1,n2,f1,f2,f3 zurückgeben und in columns der tabelle ausgeben
    --für jeden grader eine neue column erzeugen
    --median berechnen
    --grafiken anzeigen

--erstell AnalysePage mit mitgegeben Parametern
createAnPage :: String -> String -> String -> String -> String -> String
createAnPage aName gName cont test test2 = linkStringArrayAn [
  "<!doctype html>",
  "<html lang='en'>",
  "  <head></head>",
  "  <body>",
  "    <h1>Author: " ++ aName ++ "</h1>",
  "       <table border=\"true\" style=\"width:80%\">",
  "         <tr><th>Grader-Name</th><th>N1</th><th>N2</th><th>F1</th><th>F2</th><th>F3</th></tr>",
  "         <tr><th>" ++ gName ++ "</th><th>" ++ cont ++ "</th></tr>",
  "       </table>",
  "        <div>",
  "             <a>" ++ test ++ "</a>",
  "             <a>" ++ test2 ++ "</a>",
  "        </div>",
  "  </body>",
  "</html>"]


--erstellt Liste
createListAn :: String -> String
createListAn listItem = "<a>" ++ listItem ++ "</a><br>"

--erstellt den Listeninhalt
createListCont :: String -> String
createListCont cont = "<ul>" ++ cont ++ "</ul"

--erstellt eine Liste mit den Grader-Namen
createGraderList :: String -> String
createGraderList gName = gName

--entfernt die Dateiendung .txt
killEnding :: String -> String
killEnding xs = [ x | x <- xs, not (x `elem` ".txt") ]

--sollte testweise zwei Strings zu einem [Char] zusammenhängen
convString :: String -> String -> [Char]
convString a b = "data/" ++ a ++ "/" ++ b

--calcMedian :: [Int] -> Int
--calculates median according to all n1, n2, f1, f2, f3

--drawHistogramm ::
--draws histograms according to the grades (height = amount of graders, widht = 0,1,2)

--fillHistogramm ::
--fills squares according to graders grades

--Gibt das Format der Aneinanderreihung an
linkStringArrayAn :: [String] -> String
linkStringArrayAn [] = ""
linkStringArrayAn [s] = s
linkStringArrayAn (s:s' :ss) = s ++ linkStringArrayAn (s':ss)