module Hgrade.Example where
    
import System.Directory (getDirectoryContents, doesDirectoryExist)
import Control.Monad

-- |Nur hier um zu testen :)
unlines' :: [String] -> String
unlines' [] = ""
unlines' [s] = s
unlines' (s:s':ss) = s  ++ "\n" ++ unlines' (s':ss)

