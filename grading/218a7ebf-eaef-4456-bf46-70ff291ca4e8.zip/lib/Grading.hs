--Modul für GradingPage
module Grading where

--verschiedene labels welche parameter nach button-action als int array in den ordner des authros und filename gradername speichert

--createPage :: String -> String
--createPage title = unlines' [
--"<!doctype html>"
--"<html lang="en">"
--"<head></head>"
--"<body>"
 -- "<h1>Hello!</h1>"
 -- "<p>Mit folgendem <a href="/list/data">Link</a> fragen Sie die Anzahl Dateien im data-Ordner ab.</p>"

 -- "<p>Mit folgendem Formular k&ouml;nnen Sie einen Parameter namens "Name" mittels POST-Request "hochladen":</p>"
 -- "<form action='/name' method='post'>"
  --  "<label for='Name_ID'>Name:</label>"
   -- "<input type='text' id='Name_ID' name='Name'></input>"
   -- "<input type='submit' value='Send'></input>"
  --"</form>"
--"</body>"
--"</html>"


--erstellt Grading-Page
createGradingHtml :: String -> String -> String -> String -> String -> String -> String -> String -> String
createGradingHtml labAut labGra labN1 labN2 labF1 labF2 labF3 bS = "<h1>Grade</h1>" ++ labAut ++ labGra ++ labN1 ++ labN2 ++ labF1 ++ labF2 ++ labF3 ++ bS

--erstellt Label für Author
createLabelAut :: String
createLabelAut = "<label for\"author\">Author:</label><br><input type=\"String\" name=\"author\"><br><br>"

--erstellt Label für Grader
createLabelGrad :: String
createLabelGrad = "<label for\"grader\">Grader:</label><br><input type=\"String\" name=\"grader\"><br><br>"

--erstellt Label für N1
createLabelN1 :: String
createLabelN1 = "<label for\"n1\">N1:</label><br><input type=\"String\" name=\"n1\"><br><br>"

--erstellt Label für N2
createLabelN2 :: String
createLabelN2 = "<label for\"n2\">N2:</label><br><input type=\"String\" name=\"n2\"><br><br>"

--erstellt Label für F1
createLabelF1 :: String
createLabelF1 = "<label for\"f1\">F1:</label><br><input type=\"String\" name=\"f1\"><br><br>"

--erstellt Label für F2
createLabelF2 :: String
createLabelF2 = "<label for\"f2\">F2:</label><br><input type=\"String\" name=\"f2\"><br><br>"

--erstellt Label für F3
createLabelF3 :: String
createLabelF3 = "<label for\"f3\">F3:</label><br><input type=\"String\" name=\"f3\"><br><br>"

--erstellt Button
createButton :: String
createButton = "<button type=\"button\" onClick=\"alert('Der Knopf macht etwas')\">Submit!</button>"

--createFile :: String -> String -> FilePath
--createFile a g = writeFile "data/" ++ a ++ "/" ++ g ++ ""

--argFile :: String -> String -> FilePath
--argFile dir fina = "/" ++ dir ++ "/" ++ fina ++ ".txt"

--argList :: [String] -> String
--argList = "[" ++ "n1" ++ "," ++ "n2" ++ "," ++ "f1" ++ "," ++ "f2" ++ "," ++ "f3" ++ "]"