--Modul für IndexPage
module Index where

--erstellt HomePage
homePage :: String
homePage = hpLinkStringArray [
  "<!doctype html>",
  "<html lang='en'>",
  "  <head></head>",
  "  <body>",
  "    <h1>Peergrading with Haskell</h1>",
  "         <ul>",
  "             <li><a href=\"authors\">Grading Overview</a></li>",
  "             <li><a href=\"/grade\">Submit Grading</a></li>",
  "         </ul>",
  "  </body>",
  "</html>"]



hpLinkStringArray :: [String] -> String
hpLinkStringArray [] = ""
hpLinkStringArray [s] = s
hpLinkStringArray (s:s' :ss) = s ++ hpLinkStringArray (s':ss)