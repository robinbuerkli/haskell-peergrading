{-# LANGUAGE OverloadedStrings #-}

module Hgrade where

import           Web.Scotty
import           Control.Monad.IO.Class (liftIO)
import           Network.Wai.Middleware.RequestLogger ( logStdoutDev )
import qualified Data.Text.Lazy as T
import           System.Directory
import           Index
import           Authors
import           Grading
import           Analyse


main :: IO ()
main = do
  putStrLn "gl hf"

  scotty 4000 $ do
    middleware logStdoutDev
    
    --calls IndexHtml-Page
    get "/" $ do
                let hpGen = Index.homePage
                html (T.pack hpGen)

    --calls AuthorHtml-Page with Parameters
    get "/authors" $ do allDirs <- liftIO(listDirectory "data")
                        let dirs = allDirs
                        let ap1 = map createLinkAuP dirs
                        let ap2 = map createListAuP ap1
                        let ap3 = linkStringArray ap2
                        let ap4 = createListAuP ap3
                        let authorPage = createAuthorsHtml ap4
                        html (T.pack authorPage)

    --calls AnalyseHtml-Page und übergibt Parameter
    get "/authors/:aName" $ do
                              authorName <- param "aName"
                              let actDir = authorName                              
                              allFiles <- liftIO(listDirectory("data/" ++ actDir))
                              let files = allFiles
                              --let anp1 = createTableHeader
                              let anp21 = map createListAn files
                              let anp22 = linkStringArrayAn anp21
                              let anp23 = killEnding(linkStringArrayAn anp21)
                              let anp24 = convString actDir anp22
                              content <- liftIO(readFile "data/author1/grader1.txt")
                              let anp31 = createListCont content
                              let anp32 = linkStringArray [anp31]
                              let analysePage = createAnPage authorName anp23 anp22 anp31 anp24
                              html (T.pack analysePage)

    --call GradingHtml-Page                          
    get "/grade" $ do
                      let g1 = createLabelAut
                      let g2 = createLabelGrad
                      let g3 = createLabelN1
                      let g4 = createLabelN2
                      let g5 = createLabelF1
                      let g6 = createLabelF2
                      let g7 = createLabelF3
                      let g8 = createButton
                      let gradingPage = createGradingHtml g1 g2 g3 g4 g5 g6 g7 g8
                      html (T.pack gradingPage)



    get "/static/styles.css" $ file "static/styles.css"
