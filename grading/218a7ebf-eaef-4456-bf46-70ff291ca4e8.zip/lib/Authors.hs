--Modul für AuthorPage
module Authors where

--Authoren aus data auslesen und als link auf authorshtml auflisten

--authorsPage :: String -> String
--authorsPage aname = unlines' [
--  "<!doctype html>",
--  "<html lang='en'>",
--  "  <head></head>",
--  "  <body>",
-- "    <h1>Authors</h1>",
--  "  </body>",
--  "</html>"]


--Erstellt den Seitentitel
createAuthorsHtml :: String -> String
createAuthorsHtml aTitle = "<h1>Authors</h1>" ++ aTitle

--Erstellt eine Liste
createListAuP :: String -> String
createListAuP listItem = "<li>" ++ listItem ++ "</li>"

--Fügt der Liste "Kolonnen" hinzu
createListItemsAuP :: String -> String
createListItemsAuP listName = "<ul>" ++ listName ++ "</ul>"

--Fügt in die "Kolonnen" die richtigen Authoren-Links ein
createLinkAuP :: String -> String
createLinkAuP linkName = "<a href=\"authors\\" ++ linkName ++ "\">" ++ linkName ++ "</a>"

--Konvertriert, respektive hängt Strings aneinander
linkStrings :: String -> String -> String
linkStrings a b = a ++ b

--Gibt das Format der Aneinanderreihung an
linkStringArray :: [String] -> String
linkStringArray [] = ""
linkStringArray [s] = s
linkStringArray (s:s' :ss) = s ++ linkStringArray (s':ss)