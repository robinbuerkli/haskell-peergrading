{-# LANGUAGE OverloadedStrings #-}

module Hgrade where

import           Hgrade.Htmlbuilder
import           Control.Monad (when, unless)
import           Web.Scotty
import           Control.Monad.IO.Class (liftIO)
import           System.Directory
import           Network.Wai.Middleware.RequestLogger ( logStdoutDev )
import qualified Data.Text.Lazy as T
import           System.Environment
import           System.Random


main :: IO ()
main = do
  args <- getArgs
  -- | Create demo data
  when (or $ map checkDemo args) $ do
    putStrLn "\nAlright Sparky creating your demo data"
    putStrLn "\nBut be aware this takes a few secs..."
    dataExist <- doesDirectoryExist "data/"
    when dataExist $ removeDirectoryRecursive "data/"
    createDirectory "data/"
    seed <- newStdGen

    let (dirCount, _) = randomR (3,5) seed :: (Int, StdGen)
    mapM_ (\i -> createDirectory ("data/author"++ show i)) [1..dirCount]
    graderFiles <- listDirectory "data/"

    let fileGen grader i = do
          let graderFile = "data/" ++ grader ++ "/grader" ++ show i ++ ".txt"
          createFile graderFile
          markSeed <- newStdGen
          let marks = take 5 $ randomRs (0,2) markSeed :: [Int]
          writeFile graderFile (show marks)
    let helpFiles graderDir = do
          seedFile <- newStdGen
          let (graderCount, _) = randomR (1,5) seedFile  :: (Int, StdGen)
          mapM_ (fileGen graderDir) [1..graderCount]
    mapM_ helpFiles graderFiles
    return()

  putStrLn "\nStarting webserver and \n"
  -- | Starting point for server using port 4000
  scotty 4000 $ do
    middleware logStdoutDev
    -- | build the necessary html pages and get the style sheet
    get "/" $ genHtml homePage
    get "/styles.css" $ file "static/styles.css"
    get "/authors" $ do
      authors <- liftIO $ listDirectory "data/"
      genHtml $ authorPage authors
    get "/grade" $ genHtml gradePage
    -- | post request to save the data from the form
    -- | of the grading page. Use the authors name as
    -- | folder name and graders name as file name.
    post "/grade" $ do
      -- | get the criteriasList form the form
      paramsList <- params
      let unpackedValues = map (unpackParams paramsList) critereiasList
      grader <- param "grader"
      author <- param "author"

      let dirPath = "data/" ++ author
      let filePath = dirPath ++ "/" ++ grader ++".txt"

      -- |If directory doesn't exist create a new one
      dirExist <- liftIO $ doesDirectoryExist dirPath
      unless dirExist (liftIO $ createDirectory dirPath)

      -- |If file doen't exist create a new one
      fileExist <- liftIO $ doesFileExist filePath
      unless fileExist (liftIO $ createFile filePath)
      {-liftIO $ writeFile filePath ("[" ++ n1 ++ "," ++ n2 ++ ","
                                   ++ f1 ++ "," ++ f2 ++ "," ++ f3 ++ "]")-}

      liftIO $ writeFile filePath (show (unpackedValues))
      -- | redirect to authors page
      redirect "/authors"
    -- | display authors folders and files
    get "/authors/:details" $ do
      graderFolder <- param "details"
      graderFiles <- liftIO (listDirectory ("data/" ++ graderFolder))

      markList <- liftIO $ mapM (\x -> readFile $ "data/" ++ graderFolder ++ "/" ++ x)
                  graderFiles

      genHtml $ gradingPage graderFolder graderFiles (map read markList)

-- | Create the html
genHtml :: String -> ActionM ()
genHtml s = html $ T.pack s


-- | Create the file
createFile :: FilePath -> IO ()
createFile name = writeFile name ""

checkDemo :: String -> Bool
checkDemo arg = case arg of
                  "demo" -> True
                  "-demo" -> True
                  _      -> False


-- | Function to unpack the ActionM params from Scotty
unpackParams :: [Param] -> String -> Int
unpackParams ((x, y):xs)s
  | (T.unpack x) == s = read (T.unpack y)
  | otherwise = unpackParams xs s
