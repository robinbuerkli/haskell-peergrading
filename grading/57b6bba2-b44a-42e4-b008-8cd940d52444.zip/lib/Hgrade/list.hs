listToLine :: [String] -> String
listToLine (x:xs) = x ++ "\n" ++ listToLine xs