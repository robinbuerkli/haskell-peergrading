:t read
read :: Read a => String -> a

type FilePath = String

readFile :: FilePath -> IO String

writeFile :: FilePath-> String -> IO ()

main = do content <- readFile "in.txt"
          writeFile "out.txt" content

action = getLine >>= \s putStr (reverse s) >> writeFile "foo.txt" s


readGrades :: FilePath -> IO GradeList
readGrades file = do
    exists <- doesFileExist file
    if not exists then return []
    else do
        content <- readFile file
        let grades = if null content then [] else (read content)
        return $! grades

writeGrades :: FilePath -> GradeList -> IO ()
writeGrades file grades = writeFile file (show grades)

addGrade :: String -> GradeList -> GradeList
addGrade grade grades = grades ++ [(False, grade)]


