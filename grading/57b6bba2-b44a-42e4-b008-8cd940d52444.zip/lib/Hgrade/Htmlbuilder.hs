module Hgrade.Htmlbuilder where
import Data.Char
import Data.List
import System.FilePath(takeBaseName)
import Hgrade.Util

-- | Function to create the only starting and beginning html-tag
finalTag :: [[String]] -> String -> String -> [String]
finalTag sll t att = ["<" ++ t ++ checkSpace ++ att ++ ">"] ++ concat sll ++ checkClose
  where
    checkSpace :: String
    checkSpace
      | att /= "" = " "
      | otherwise = ""
    checkClose :: [String]
    checkClose
      | t /= "link" = ["</" ++ t ++ ">"]
      | otherwise = []

-- | assign constants to the criterias used in
-- | the grading page
critereiasList :: [String]
critereiasList = ["n1", "n2", "f1", "f2", "f3"]


-- | Start of helper html functions
-- | The following functions are helper functions
-- | to create each needed html-tag for the application.
-- | The single tag uses the finalTag function to create the opening
-- | and closing tags
singleTag :: [[String]] -> String -> [String]
singleTag sll t = finalTag sll t ""

htmlTag :: [[String]] -> [String]
htmlTag sll = singleTag sll "html"

headTag :: [[String]] -> [String]
headTag sll = singleTag sll "head"

p :: [[String]] -> [String]
p sll = singleTag sll "p"

body :: [[String]] -> [String]
body sll = singleTag sll "body"

ul :: [[String]] -> [String]
ul sll = singleTag sll "ul"

li :: [[String]] -> [String]
li sll = singleTag sll "li"

table :: [[String]] -> [String]
table sll = singleTag sll "table"

tr :: [[String]] -> [String]
tr sll = singleTag sll "tr"

td :: [[String]] -> [String]
td sll = singleTag sll "td"

td' :: String -> [[String]] -> [String]
td' att sll = finalTag sll "td" att

h1 :: [[String]] -> [String]
h1 sll = singleTag sll "h1"

h2 :: [[String]] -> [String]
h2 sll = singleTag sll "h2"

th :: [[String]] -> [String]
th sll = singleTag sll "th"

sp :: [[String]] -> [String]
sp sll = singleTag sll "sp"

divc :: String -> [[String]] -> [String]
divc c sll = finalTag sll "div" ("class=\'" ++ c ++ "\'")

divi :: String -> [[String]] -> [String]
divi i sll = finalTag sll "div" ("id=\'" ++ i ++ "\'")

tdc :: String -> [String]
tdc col = td' ("bgcolor=\'" ++ col ++ "\'style=\'height:20px;width:20px;\'") []

blackBox :: [String]
blackBox = tdc "black"

whiteBox :: [String]
whiteBox = tdc "white"

a :: String -> [[String]] -> [String]
a href sll = finalTag sll "a" ("href=\'" ++ href ++ "\'")

form :: String -> String -> [[String]] -> [String]
form action method sll = finalTag sll "form" ("action=\'" ++
                                               action ++ "\' method=\'" ++ method ++ "\'")

button :: String -> [String] -> [String]
button s link = finalTag [link] "a" ("href=\'" ++ s ++ "\' class=\'Button\'")

input :: [[String]] -> String -> [String]
input sll = finalTag sll "input"

inputText :: String -> String -> [[String]] -> [String]
inputText t name sll = input sll ("type=\'" ++ t ++ "\' name=\'"++ name ++ "\'")

submit :: [String] -> [String]
submit s = input [] ("type=\'submit\' name=\'"++
                      concat s ++ "\' value=\'"++ concat s ++ "\'")

linkStyle :: String -> [String]
linkStyle s = finalTag [] "link" ("rel = \'stylesheet\' href=\'" ++ s ++ "\'")
-- | End of helper html functions

-- | Function to create the htmlWrapper
htmlWrapper :: String -> String
htmlWrapper content = unlines' $ htmlTag
                      [
                        headTag [linkStyle "/styles.css"],
                        body [[content]]
                      ]

-- | Function to which uses the htmlWrapper to create a page
createPage :: String -> String
createPage title = htmlWrapper $ unlines' $ divc "container"
                     [body
                       [p [[title]],
                        p [["test"]]]
                     ]


-- | Function to create the home page of the grader
-- | uses the above defined functions to build the list of html-tags
homePage :: String
homePage = htmlWrapper $ unlines' $
                     divc "container"
                       [h1 [["Hgrade"]],
                        h2 [["Peergrading in Haskell"]],
                        ul
                         [ li [a "/authors" [["Grading Overview"]]],
                           li [a "/grade" [["Submit Grading"]]]
                         ]
                       ]


-- | Function to create the home page of the grader
-- | uses the above defined functions to build the list of html-tags
gradePage :: String
gradePage = htmlWrapper $ unlines' $
                     divc "container"
                       [h1 [["Grades"]],
                        form "/grade" "post"
                        $ map helper (["author", "grader"] ++ critereiasList)
                          ++ [submit ["send"]],
                         button "/" ["Home"]
                       ]
  where
    helper :: String -> [String]
    helper s = divi s [sp [[firstLetterCaps s ++ ":"]], inputText "text" s []]

    firstLetterCaps :: String -> String
    firstLetterCaps [] = []
    firstLetterCaps (x:xs) = toUpper x:xs

-- | Build the single authors page
authorPage :: [String] -> String
authorPage authorNames = htmlWrapper $ unlines' $
                    divc "container"
                      [h1 [["Authors"]],
                       ul [concatMap helper (authorNames \\ [".", ".."])],
                       button "/" ["Home"]
                      ]
  where
    helper :: String -> [String]
    helper s = li [a ("/authors/" ++ s) [[s]]]


-- | Functions to build the grading overview page
-- | takes the transposed (col to row) marks from the grading
-- | and fills it into the table created with the htmlWrapper function
gradingPage :: String -> [String] -> [[Int]] -> String
gradingPage author grader marks = htmlWrapper $ unlines' $
               divc "container"
                 [ h1 [["Authors: " ++ author]],
                   table
                   [
                     tr [th [[""]],concatMap helpHeader critereiasList],
                     concatMap helpGrade zippedGrader,
                     tr [td [["Median"]], concatMap (medianToTable . median)
                                          transposedMarks],
                     tr [td [["Histogram"]], concatMap helpBuildHisto transposedMarks]
                   ],
                   button "/" ["Home"]
                 ]
  where
    transposedMarks :: [[Int]]
    transposedMarks = colSToRows marks

    helpBuildHisto :: [Int] -> [String]
    helpBuildHisto xs = td [table (createTable (histogram xs) (length xs))]
      where
        createTable :: [Int] -> Int -> [[String]]
        createTable tu l
          | l == 1 = [tr [concatMap fillRow tu]]
          | otherwise = tr [concatMap fillRow tu]:createTable tu (l-1)
            where
              fillRow :: Int -> [String]
              fillRow x
                | x >= l = blackBox
                | otherwise = whiteBox

    helpHeader :: String -> [String]
    helpHeader s = th [[s]]

    helpGrade :: (String, [Int]) -> [String]
    helpGrade (gr, mr) = tr [td [[takeBaseName gr]], concatMap helpMarking mr]

    helpMarking :: Int -> [String]
    helpMarking mark = td [[show mark]]

    zippedGrader :: [(String, [Int])]
    zippedGrader = zip grader marks

    medianToTable :: Int -> [String]
    medianToTable m = td[[show m]]
