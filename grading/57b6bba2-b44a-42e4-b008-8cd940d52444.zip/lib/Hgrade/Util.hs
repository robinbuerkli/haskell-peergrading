module Hgrade.Util where
import Data.List



-- |Function which converts from list of string to string
unlines' :: [String] -> String
unlines' [] = ""
unlines' [s] = s
unlines' (s:s':ss) = s  ++ "\n" ++ unlines' (s':ss)

-- |Converts columns to rows with the use of transpose
colSToRows :: [[a]] -> [[a]]
colSToRows = transpose

-- |Creates a histogram from a given int list
histogram :: [Int] -> [Int]
histogram xs = [noOfOcc 0, noOfOcc 1, noOfOcc 2]
  where
    noOfOcc :: Int -> Int
    noOfOcc x =  length $ filter (x==) xs

-- |Computes the median from a list of integers
-- |Formula for median is split into odd and even case
-- |List needs to be sorted
median :: [Int] -> Int
median xs = case xs of
                  []  -> error "Empty list given for median"
                  [x] -> x
                  [x,y] -> (x + y) `div` 2
                  _  | odd $ length xs -> sortIndex mid
                     | otherwise -> (sortIndex mid + sortIndex (mid - 1)) `div` 2
    where
      mid :: Int
      mid = length xs `div` 2

      sortIndex :: Int -> Int
      sortIndex i = sort xs !! i
