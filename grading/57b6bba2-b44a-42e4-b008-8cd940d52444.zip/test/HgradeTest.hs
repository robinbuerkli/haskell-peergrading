module Main (main) where

import Hgrade.Util
import           Data.Maybe  (mapMaybe)
import           System.Exit

data Test = Test String TestResult

data TestResult = PASS | Fail String deriving (Eq, Show)

assertEq :: (Eq a, Show a) => a -> a -> TestResult
assertEq actual expected
  | actual == expected = PASS
  | otherwise = Fail (show actual ++ " is not equal to\n" ++ show expected)

testList :: [TestResult] -> TestResult
testList t = case mapMaybe failMessage t of
  []       -> PASS
  messages -> Fail (unlines messages)
  where
    failMessage :: TestResult -> Maybe String
    failMessage PASS       = Nothing
    failMessage (Fail m) = Just m

runTests :: [Test] -> IO ()
runTests t = case t of
  [] -> exitSuccess
  Test msg PASS:ts -> do
    putStrLn ("PASS: " ++ msg)
    runTests ts
  Test msg (Fail failMsg):_ -> do
    putStrLn ("FAIL: " ++ msg)
    putStrLn failMsg
    exitFailure


main :: IO ()
main = runTests tests

tests :: [Test]
tests = [histogramTest,medianTest, colsToRowsTest ]

-- | Functionality test for the histogram
histogramTest :: Test
histogramTest = Test
                "Histogram"
                (testList [
                    assertEq
                    (histogram [1, 0, 2, 1,0]) [2,2,1],
                    assertEq
                    (histogram [1, 2, 1]) [0,2,1]
                          ])
-- | Computational test for median function
medianTest :: Test
medianTest = Test
             "Median"
             (testList [
                 assertEq
                 (median [0,2,2,2,0]) 2,
                 assertEq
                 (median [0,2,2,0]) 1
                       ])
-- | Testcase for the col to row function
colsToRowsTest :: Test
colsToRowsTest = Test
             "colsToRows"
             (testList [
                 assertEq
                 (colSToRows ([[0,1],[2,3]] :: [[Int]])) ([[0,2],[1,3]] :: [[Int]]),
                 assertEq
                 (colSToRows ([[0],[2]] :: [[Int]]))  ([[0,2]] :: [[Int]])
                       ])
