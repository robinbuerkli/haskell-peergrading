{-# LANGUAGE OverloadedStrings #-}

-- |Main entry point of application, defining the GET and POST interfaces with scotty
module Main where

import qualified Hgrade.HTML as HTML
import qualified Hgrade.IO as IO
import qualified Hgrade.Util as Util

import qualified Data.Text.Lazy as T
import           Control.Monad.IO.Class (liftIO)
import           Network.Wai.Middleware.RequestLogger (logStdoutDev)
import           System.Directory (listDirectory, createDirectoryIfMissing)
import           Web.Scotty (file, get, html, middleware, param, post, scotty)

-- |Constant with grading category names
gradingNames :: [String]
gradingNames = ["N1", "N2", "F1", "F2", "F3"]

-- |Main entry point
main :: IO ()
main = do
  IO.handleDataGeneration
  scotty 4000 $ do
    middleware logStdoutDev

    get "/" $ do
      file "static/index.html"

    get "/authors" $ do
      files <- liftIO (listDirectory "data")
      html (T.pack (HTML.createPage "Authors" ("<ul>" ++ HTML.asAuthorList files ++ "</ul>")))

    get "/authors/:author" $ do
      author <- param "author"
      files <- liftIO (listDirectory ("data/" ++ author))
      contents <- liftIO(mapM (IO.getFileContent author) files)
      let fileContent = zip files contents
      let grades = Util.createGrades fileContent
      let gradeMatrix = Util.asGradeMatrix grades
      let transposedMatrix = Util.colsToRow gradeMatrix
      let medians = map Util.median transposedMatrix
      let histograms = map (Util.getHistogram (length grades)) transposedMatrix 
      html (T.pack (HTML.createPage ("Author: " ++ author) ( "<br>" ++ "<table><tr><th>Author</th><th>N1</th><th>N2</th><th>F1</th><th>F2</th><th>F3</th></tr>" ++ HTML.asGradeTable grades ++ HTML.asMedianRow medians ++ "<td></td>"++ HTML.printHistograms histograms ++ "</table>")))

    get "/grade" $ do
      html(T.pack(HTML.createPage "Grade!" (HTML.parameterForm gradingNames)))

    post "/grade" $ do
      author <- param "Author"
      grader <- param "Grader"
      params <- mapM IO.getParam gradingNames
      let directory = "data/" ++ author
      let content = show params
      liftIO(createDirectoryIfMissing True directory)
      liftIO(writeFile ("data/" ++ author ++ "/" ++ grader ++".txt") content)

      file "static/index.html"