{-# LANGUAGE OverloadedStrings #-}

-- |This module prived function for generating HTML pages and its basic tables and lists.
module Hgrade.HTML where

import qualified Hgrade.Util as Util

-- |Generates a HTML document for with given title and body content.
createPage :: String -> String -> String
createPage title content = unlines' [
  "<!doctype html>",
  "<html lang='en'>",
  "  <head>",
  "<style>",
  "table, th, td {",
    "border: 1px solid black;",
    "border-collapse: collapse;",
  "}",
  "</style>",
  "</head>",
  "  <body>",
  "    <h1>" ++ title ++ "</h1>",
      content,
  "  </body>",
  "</html>"]

-- |Creates HTML list of given authors with links to /authors/:author:
asAuthorList :: [String] -> String
asAuthorList [] = ""
asAuthorList [s] = "<li><a href='/authors/" ++ s ++ "'>" ++ s ++ "</a></li>"
asAuthorList (s:s':ss) = "<li><a href='/authors/" ++ s ++ "'>" ++ s ++ "</a></li>"  ++ "\n" ++ asAuthorList (s':ss)

-- |Create HTML table row elements for given grades with author and values
asGradeTable :: [Util.Grade] -> String
asGradeTable [] = ""
asGradeTable [g] = "<tr><td>" ++ Util.author g ++ "</td>" ++ getRatingsAsCells (Util.ratings g) ++ "</tr>"
asGradeTable (g:g':gg) = "<tr><td>" ++ Util.author g ++ "</td>" ++ getRatingsAsCells (Util.ratings g) ++ "</tr>"  ++ "\n" ++ asGradeTable (g':gg)

-- |Print given medians as HTML table rows
asMedianRow :: [Double] -> String
asMedianRow [] = ""
asMedianRow medians = "<tr><td>Median</td>" ++ getMediansAsCells medians ++ "</tr>"

-- |Create HTML table row elements for given grades with author and values
getMediansAsCells :: [Double] -> String
getMediansAsCells [] = ""
getMediansAsCells [m] = "<td>" ++ show m ++ "</td>"
getMediansAsCells (m:m':mm) = "<td>" ++ show m ++ "</td>" ++ "\n" ++ getMediansAsCells (m':mm)

-- |Create HTML table cell elements for given ratings
getRatingsAsCells :: [Int] -> String
getRatingsAsCells [] = ""
getRatingsAsCells [r] = "<td>" ++ show r ++ "</td>"
getRatingsAsCells (r:r':rr) = "<td>" ++ show r ++ "</td>" ++ "\n" ++ getRatingsAsCells (r':rr)

-- |Concats list of strings into single string
unlines' :: [String] -> String
unlines' [] = ""
unlines' [s] = s
unlines' (s:s':ss) = s  ++ "\n" ++ unlines' (s':ss)

-- |Print HTML table cell elements as single tables of histogram
printHistograms :: [Util.Histogram] -> String 
printHistograms [] = ""
printHistograms [h] = "<td><table>" ++ printHistogram (Util.maxValue h) h ++ "</table></td>"
printHistograms (h:h':hh) = "<td><table>" ++ printHistogram (Util.maxValue h) h ++ "</table></td>"  ++ "\n" ++ printHistograms (h':hh)

-- |Print HTML table row element with given number of elements for height 
printHistogram :: Int -> Util.Histogram -> String
printHistogram currentCount h
  | currentCount == 0 = ""
  | otherwise = "<tr>" ++ histogramRow [(currentCount) - (Util.zeroPoints h) <= 0, (currentCount) - (Util.onePoints h) <= 0, (currentCount) - (Util.twoPoints h) <= 0] ++ "</tr>" ++ printHistogram (currentCount -1) h

-- |Print single histogram row, represented as bool with true for black and false for white
histogramRow :: [Bool] -> String
histogramRow [] = ""
histogramRow [b]
  | b =  "<td bgcolor=\"black\" style=\"height:20px;width:20px\"></td>"
  | otherwise = "<td bgcolor=\"white\" style=\"height:20px;width:20px\"></td>"
histogramRow (b:b':bb) 
  | b =  "<td bgcolor=\"black\" style=\"height:20px;width:20px\"></td>" ++ histogramRow (b':bb)
  | otherwise = "<td bgcolor=\"white\" style=\"height:20px;width:20px\"></td>" ++ histogramRow (b':bb)

-- |Create parameter form for given parameters and pack it with form tag and static labels
parameterForm :: [String] -> String
parameterForm parameter = "<form action='/grade' method='post'>" ++ 
    "<label for='Author'>Author:</label><input type='text' id='Author' name='Author'></input></br>" ++
    "<label for='Grader'>Grader:</label>" ++
    "<input type='text' id='Grader' name='Grader'></input>" ++
    "</br>" ++ (generateGradingForm parameter)  ++ "</form>"

-- |Generate parameter form for given parameters
generateGradingForm :: [String] -> String
generateGradingForm [] = ""
generateGradingForm [gradingParameter] = (generateTextBox gradingParameter) ++ "<input type='submit' value='Send'></input>"
generateGradingForm (g:g':gg) = (generateTextBox g)  ++ generateGradingForm (g':gg)

-- |Generate single textbox with label for given parameter
generateTextBox :: String -> String
generateTextBox parameterName = "<label for='" ++ parameterName ++ "'>" ++ parameterName ++ ":</label><input type='text' id='" ++ parameterName ++ "' name='" ++ parameterName ++ "'></input></br>"