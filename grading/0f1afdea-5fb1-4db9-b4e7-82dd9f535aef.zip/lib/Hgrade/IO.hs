{-# LANGUAGE OverloadedStrings #-}

-- |This module contains IO functions for working with directory, random numbers and scotty
module Hgrade.IO where
  
import qualified Hgrade.Util as Util
  
import qualified Data.Text.Lazy as T

import System.Directory (createDirectoryIfMissing)
import System.Random
import System.Environment
import Control.Monad.IO.Class (liftIO)
import Web.Scotty (ActionM, param)

-- |Get file content for given graer in author directory
getFileContent :: String -> FilePath -> IO String
getFileContent a f = do
  content <- readFile (getFullFileName a f)
  return content

-- |Generate full file name for relative path from author and grader name
getFullFileName :: String -> FilePath -> FilePath
getFullFileName "" "" = ""
getFullFileName _ "" = ""
getFullFileName "" _ = ""
getFullFileName a f = "data/" ++ a ++ "/" ++ f

-- |Checks if --data parameter was given and initializes generate data, if given
handleDataGeneration :: IO ()
handleDataGeneration = do
  shouldGenerate <- shouldGenerateData
  if shouldGenerate
    then generateTestData
    else return ()

-- |Generates test data for 3 - 5 authors with 1 - 3 grades
generateTestData :: IO ()
generateTestData = do
    createDirectoryIfMissing True "data"
    ran <- randomRIO (3,5) :: IO Int
    generateAuthors ran
    return ()

-- |Generate author names and initialize directory creation, using a count variable for name
generateAuthors :: Int -> IO ()
generateAuthors currentCount
  | currentCount == 0 = return ()
  | otherwise = do
    generateAuthor ("author" ++ show currentCount)
    generateAuthors (currentCount - 1)

-- |Creates author directory for given author name and initializes grading generation
generateAuthor :: String -> IO ()
generateAuthor authorName = do
    createDirectoryIfMissing True ("data/" ++ authorName)
    nOfReviews <- randomRIO (1,3) :: IO Int
    generateGrades nOfReviews authorName
    return ()

-- |Generates n grades for given author name directory with using n for grader name
generateGrades :: Int -> String -> IO()
generateGrades currentCount authorName 
  | currentCount == 0 = return ()
  | otherwise = do
    value1 <- liftIO(randomRIO (0,2) :: IO Int)
    value2 <- liftIO(randomRIO (0,2) :: IO Int)
    value3 <- liftIO(randomRIO (0,2) :: IO Int)
    value4 <- liftIO(randomRIO (0,2) :: IO Int)
    value5 <- liftIO(randomRIO (0,2) :: IO Int)
    writeFile ("data/" ++ authorName ++ "/" ++ "grader" ++ show currentCount ++ ".txt") (show [value1, value2, value3, value4, value5])
    generateGrades (currentCount - 1) authorName

-- |Check parameters and returns if --data parameter is available
shouldGenerateData :: IO Bool
shouldGenerateData = do
  args <- getArgs
  let shouldGenerate = Util.containsElement args "-data"
  return shouldGenerate

-- |Gets single parameter with given name
getParam :: String -> ActionM Int
getParam s = param (T.pack s) :: ActionM Int