{-# LANGUAGE OverloadedStrings #-}
-- |This module provides various util functions for list insight
module Hgrade.Util where
  
import Data.List

-- |Represents a grade given by a single author
data Grade = MakeGrade { author :: String
                 , ratings   :: [Int] 
                 } deriving (Show)

-- |Represents single historogram with number of points given per avaiable grade
data Histogram = MakeHistogram { 
                 maxValue :: Int
                 , zeroPoints :: Int
                 , onePoints :: Int
                 , twoPoints :: Int
                 } deriving (Show)

-- |Generates matrix from given grades, with rows representing the values of the grades
asGradeMatrix :: [Grade] -> [[Int]]
asGradeMatrix [] = []
asGradeMatrix [g] = [ratings g]
asGradeMatrix (g:g':gg) = [ratings g] ++ asGradeMatrix (g':gg)

-- |Transposes given matrix
colsToRow:: [[Int]] -> [[Int]]
colsToRow [] = []
colsToRow ([]:_) = []
colsToRow matrix = (map head matrix) : colsToRow (map tail matrix)

-- |Create grades for given ratings and files, strapping the file ending of the file name
createGrades :: [(FilePath, String)] -> [Grade]
createGrades [] = []
createGrades [(a, c)] = [MakeGrade (stripChars ".txt" a) (read c)]
createGrades ((a,c):xs) = [MakeGrade (stripChars ".txt" a) (read c)] ++ createGrades xs

-- |Strips of given string in second string
stripChars :: String -> String -> String
stripChars = filter . flip notElem

-- |Creates list of number of occuring possible ratings 0,1,2 in given list as list of length 3
histogram :: [Int] -> [Int]
histogram [] = []
histogram values = [zeroPointsValue, onePointsValue, twoPointsValue]
  where sortedValues = sort values
        zeroPointsValue = getNumberOfOccurancesInList (groupBy (==) sortedValues) 0
        onePointsValue = getNumberOfOccurancesInList (groupBy (==) sortedValues) 1
        twoPointsValue = getNumberOfOccurancesInList (groupBy (==) sortedValues) 2

-- |Creates histogram from given max length as number of graders and list of number of points occuring
getHistogram :: Int -> [Int] -> Histogram
getHistogram maxV values = MakeHistogram maxV zeroPointsValue onePointsValue twoPointsValue
  where histoValues = histogram values
        zeroPointsValue = histoValues!!0
        onePointsValue = histoValues!!1
        twoPointsValue = histoValues!!2

-- |Counts in list number of occuring number and returns value
getNumberOfOccurancesInList :: [[Int]] -> Int -> Int
getNumberOfOccurancesInList [] _ = 0
getNumberOfOccurancesInList [i] s 
  | all (== s) i = length i
  | otherwise = 0
getNumberOfOccurancesInList (i:i':ii) s 
  | all (== s) i = length i
  | otherwise = getNumberOfOccurancesInList (i':ii) s

-- |Finds median of given list
findMedian :: [Int] -> Double
findMedian [] = 0
findMedian [i] = fromIntegral(i)
findMedian [i1,i2] = (fromIntegral(i1) + fromIntegral(i2)) / 2
findMedian values = findMedian (reverse (tail (reverse (tail values))))

-- |Sorts given list and finds median
median :: [Int] -> Double
median [] = 0
median [i] = fromIntegral(i)
median values = findMedian (sort values)

-- |Checks if given list contains given string
containsElement :: [String] -> String -> Bool
containsElement [] _ = False
containsElement [s] searchS
  | s == searchS = True
  | otherwise = False
containsElement (s:s':ss) searchS
  | s == searchS = True
  | otherwise = containsElement (s':ss) searchS