-- |This module contains tests for the functions colsToRow, median and histogram
module Main (main) where

import Hgrade.Util
import Test.Tasty
import Test.Tasty.HUnit

-- |Main entry point for tests
main :: IO ()
main = defaultMain tests

-- |Creats test group
tests :: TestTree
tests = testGroup "Tests" [unitTests]

-- |Function containg the tests
unitTests :: TestTree
unitTests = testGroup "Unit tests"
  [ testCase "colsToRow empty list" $
      colsToRow [] @?= [],

    testCase "colToRow singleton list" $
      colsToRow [[1,2,3,4]] @?= [[1], [2], [3], [4]],

    testCase "colToRow  larger list" $
      colsToRow [[1,2,3,4], [1,2,3,4], [1,2,3,4], [1,2,3,4]] @?= [[1,1,1,1], [2,2,2,2], [3,3,3,3], [4,4,4,4]],

    testCase "median empty list" $
      median [] @?= 0,

    testCase "median singleton list" $
      median [1] @?= 1,

    testCase "median odd list" $
      median [1,2,3]  @?= 2,

    testCase "median even list" $
      median [1,2,3,4]  @?= 2.5,

    testCase "histogram empty list" $
      histogram [] @?= [],

    testCase "histogram singleton list" $
      histogram [2] @?= [0,0,1],

    testCase "histogram larger list" $
      histogram [2,0,0,1,2] @?= [2,1,2]
  ]

